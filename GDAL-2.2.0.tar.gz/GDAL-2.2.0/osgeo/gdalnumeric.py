from osgeo.gdal_array import *
from numpy import *
